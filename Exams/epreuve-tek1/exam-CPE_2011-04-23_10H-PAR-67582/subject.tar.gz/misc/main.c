#include <stdio.h>
#include <stdlib.h>

int	main(int ac, char **av)
{
  printf("%d\n", my_atoi_base(av[1], av[2]));
}
