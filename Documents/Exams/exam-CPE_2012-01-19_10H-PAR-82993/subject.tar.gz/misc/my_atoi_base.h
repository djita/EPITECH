#ifndef _MY_ATOI_H_
#define _MY_ATOI_H_

int	main(int main, char **av);
int	my_atoi_base(char *str, char *base);

#endif

